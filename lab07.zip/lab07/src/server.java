import java.io.*;
import java.util.*;
import java.net.*;

public class server {
	public static void main(String[] args) {
		// Establish server socket
		try (ServerSocket s = new ServerSocket(1000)) {
			// Wait for client connection
			try (Socket incoming = s.accept()) {
				DataInputStream inStream = new DataInputStream(incoming.getInputStream());
				DataOutputStream outStream = new DataOutputStream(incoming.getOutputStream());
						Loan loan = new Loan(inStream.readDouble(), inStream.readDouble(), inStream.readDouble());
						outStream.writeDouble(loan.calculatePayment());
						outStream.writeDouble(loan.calculatetotal());
				inStream.close();
				outStream.close();
				
				
				
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
