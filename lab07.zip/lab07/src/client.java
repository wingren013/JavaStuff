import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;


public class client {

	public DataOutputStream streamWriter = null;
	public DataInputStream streamReader = null;
	
	public client(){
	
		tf.setOnAction(e -> {
			try {
			// Get the radius from the text field
			double radius = Double.parseDouble(tf.getText().trim());
			// Send the radius to the server
			toServer.writeDouble(radius);
			toServer.flush();
			// Get area from the server
			double area = fromServer.readDouble();
			// Display to the text area
			ta.appendText("Radius is " + radius + "\n");
			ta.appendText("Area received from the server is " + area + '\n');
			}
			catch (IOException ex) {
			System.err.println(ex);
			}
			});
		
		try (Socket s = new Socket("127.0.0.1", 1000);) {
			streamReader = new DataInputStream(s.getInputStream());
			streamWriter = new DataOutputStream(s.getOutputStream());
			}
			 catch(SocketTimeoutException ex) {
			ex.printStackTrace();
			}
			catch(IOException ex) {
			ex.printStackTrace();
			}
			}
		
	}
	
	
