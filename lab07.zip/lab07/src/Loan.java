import java.text.DecimalFormat;


public class Loan {
	private double payment = 0;
	private double presentValue = 0;
	private double ratePerPeriod = 0;
	private double numberOfPeriods = 0;
	
	public Loan(){
	}
	
	public Loan(double x, double y, double z){
		this.presentValue = x;
		this.ratePerPeriod = y;
		this.numberOfPeriods = z;
	}
	
	public synchronized double getpayment(){
		return this.payment;
	}
	
	public synchronized void setpayment(double x){
		this.payment = x;
	}
	
	public double getpresentValue(){
		return this.presentValue;
	}
	
	public void setpresentValue(double x){
		this.presentValue = x;
	}
	
	public double getratePerPeriod(){
		return this.ratePerPeriod;
	}
	
	public void setratePerPeriod(double x){
		this.ratePerPeriod = x;
	}
	
	public double getnumberOfPeriods(){
		return this.numberOfPeriods;
	}
	
	public void setnumberOfPeriods(double x){
		this.numberOfPeriods = x;
	}
	
	
	
	public synchronized double calculatePayment(){
		double numerator = this.getratePerPeriod() * this.getpresentValue();
		double denominator = 1 - Math.pow(this.getratePerPeriod() + 1, this.getnumberOfPeriods() * -1);
		double x  = numerator / denominator;
		this.setpayment(x);
		return x;
	}
	
	public synchronized double calculatetotal(){
		double total = this.presentValue*this.ratePerPeriod*this.numberOfPeriods;
		return total;
	}
	
	
	
	
	
}
