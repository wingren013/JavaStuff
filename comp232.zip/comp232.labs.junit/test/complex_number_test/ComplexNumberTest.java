package complex_number_test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import Advanced_Java.ComplexNumber;

import comp232.labs.junit.first.MyClass;

public class ComplexNumberTest {

	
	@BeforeClass
	public static void testSetup(){
		
	}
	@AfterClass
	public static void testCleanup(){
	}
	
	@Test
	public static void testAdd() {
		ComplexNumber result = new ComplexNumber(10, 4);
		assertEquals("5+2i + 5+2i must be 10+4i", result , ComplexNumber.add(new ComplexNumber(5, 2), new ComplexNumber(5, 2)));
	}

}
