package Advanced_Java;

public class ComplexNumber {

	private double real;
	private double imaginary;
	
	public ComplexNumber(double real, double imaginary){
		this.real = real;
		this.imaginary = imaginary;
	}
	
	public ComplexNumber() {
	}
	
	public static ComplexNumber add(ComplexNumber x, ComplexNumber y){
		double real = x.real + y.real;
		double imaginary = x.imaginary + y.imaginary;
		String stringreal = Double.toString(real);
		String stringimaginarypre = Double.toString(imaginary);
		String stringimaginary = (stringimaginarypre += "i");
		System.out.print(stringreal);
		System.out.print(" + ");
		System.out.print(stringimaginary);
		ComplexNumber output = new ComplexNumber(real, imaginary);
		return output;
	}
	
	
	public static ComplexNumber ComplexCalculator (double a, double b, double c, double d) {
		ComplexNumber num1 = new ComplexNumber(a, b);
		ComplexNumber num2 = new ComplexNumber(c, d);
		ComplexNumber output = add(num1, num2);
		return output;
	}
	
	public static void main(String[] args) {
	ComplexCalculator(5, 2, 5, 2);
	
	}
	}

