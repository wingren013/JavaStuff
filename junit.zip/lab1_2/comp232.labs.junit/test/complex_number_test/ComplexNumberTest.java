package complex_number_test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import Advanced_Java.ComplexNumber;

import comp232.labs.junit.first.MyClass;

public class ComplexNumberTest {

	
	@BeforeClass
	public static void testSetup(){
		
	}
	@AfterClass
	public static void testCleanup(){
	}
	
	@Test
	public void testAdd() {
		ComplexNumber tester = new ComplexNumber(5, 2);
		ComplexNumber tester2 = new ComplexNumber(5, 2);
		assertEquals("5+2i + 5+2i must be 10+4i", , )
	}

}
