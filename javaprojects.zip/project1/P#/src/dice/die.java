package dice;

public class die {
	static int start;
	static int end;

	public static void main(String[] args) {
		

	}
	die(){}
	die(int x, int y){
		start = x;
		end = y;
	}

	
}
