package samples;

import javax.swing.JFrame;

import Practice.GridTime;

public class calendar extends JFrame{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calendar fraemz = new calendar();
		fraemz.setTitle("calendar");
		fraemz.setSize(900,900);
		fraemz.setLocation(0,0);
		fraemz.setVisible(true);
		fraemz.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
