package misc;

public class print_strings {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method statement
System.out.println("Hello");
	}

}
