package misc;
import javax.swing.JOptionPane;


public class welcome_to_java {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
JOptionPane.showMessageDialog(null, "Welcome To Java",
		"FROM THIS COMPUTER", JOptionPane.INFORMATION_MESSAGE);
	}

}
