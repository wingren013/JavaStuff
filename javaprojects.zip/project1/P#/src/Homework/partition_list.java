package Homework;

public class partition_list {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static int partition(int[] list){
		int x = 290304;
		
		return x;
	}

}
