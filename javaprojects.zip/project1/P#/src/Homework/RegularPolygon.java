package Homework;

public class RegularPolygon {

	/**
	 * @param args
	 */
	private int n = 3;
	private double side =1;
	private double x =0;
	private double y =0;
	public RegularPolygon(){
		
	}
	
	public RegularPolygon(int newn, double newside){
		
	}
	public RegularPolygon(int newn, double newside, double newx, double newy){
		
	}
	
	public static double getPerimeter(RegularPolygon regpoly){
		double x = 1;
		
		return x;
		
	}

}

