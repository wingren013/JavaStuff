package universal_assets$copy_and_paste;

public class dark_arts {
	public static void main(String[] args) {
System.out.println(invoke.Cthulu());
	}
}