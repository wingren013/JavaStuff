import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;


public class SplitFile {

	public static void set02_01(File file, String sString) throws IOException{
		try(FileInputStream stream = new FileInputStream(file)){
		
		int t = stream.available();
		double d = 1;
		int s = Integer.parseInt(sString);
		d = t/s;
		int dInt = (int) d;
		//check if number of pieces would be invalid 
		if(d >= 1){
			//take care of any loose pieces
			if(d-dInt != 0){
				double q = d- dInt;
				for(double i =0; i <= q*t; i++){
					
				}
			}
			
			
			
			
			
			//error message
		}else{
			System.out.println("number of pieces is less than one. creating one piece");
			}
		}
		}
	}

