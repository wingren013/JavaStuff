package lab03;

import java.util.Scanner;

public class FiveStrings {

	public static void fiveStrings(){
		GenericStack<String> stack1= new GenericStack<String>();
		Scanner input = new Scanner(System.in);
		System.out.println("enter five strings");
		String string1 = input.next();
		String string2 = input.next();
		String string3 = input.next();
		String string4 = input.next();
		String string5 = input.next();
		stack1.push(string1);
		stack1.push(string2);
		stack1.push(string3);
		stack1.push(string4);
		stack1.push(string5);
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
		System.out.println(stack1.pop());
	}
	
	public static void variableStrings(){
		GenericStack<String> stack1= new GenericStack<String>();
		Scanner input = new Scanner(System.in);
		System.out.println("enter strings");
		while (input.hasNext()){
			String inputStr = (String)input.next();
			if (inputStr.equals(10) || inputStr.equals(13)){
					break;
			}
			stack1.push(inputStr);
		}
		input.close();
		while(stack1.isEmpty() == false){
			System.out.println(stack1.pop());
		}
		
	}
	
	public static void main(String[] args) {
			variableStrings();
	}

}
