package lab03;

import java.sql.Array;

public class GenericStack<E> {
	
	
	
private Object[] list;
private int i;

	GenericStack(){
		this.i = 0;
		this.list = new Object[999];
	}

	public int getSize() {
		return this.list.length;
	}


	public E peek() {
		return (E) this.list[this.i];
	}


	public void push(E o) {
		this.i++;
		if(i > getSize()){
			Object[] arr = new Object[getSize()];
			System.arraycopy(this.list, 0, arr, 0, getSize());
			this.list = new Object[2*(getSize())];
			System.arraycopy(arr, 0, this.list, 0, getSize());
		}
		this.list[this.i] = o;
	}


	public E pop() {
		E o = (E) this.list[this.i];
		this.list[this.i] = null;
		this.i--;
		return o;
	}


	public boolean isEmpty() {
		boolean bool = false;
		if(this.list[this.i] == null){
			bool = true;
		}else{
			bool = false;
			}
		return bool;
	}


	@Override
	public String toString() {
		return "stack: " + this.list.toString();
	}


}