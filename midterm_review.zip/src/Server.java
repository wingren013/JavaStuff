import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class Server {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		try(ServerSocket s = new ServerSocket(8000)){
			

			
			
			File file = new File("State-Capitals.txt");
			FileInputStream fin = new FileInputStream(file);
			HashMap<String, String> m = new HashMap<String, String>();
			try(Scanner stream = new Scanner(file).useDelimiter("[,]")){
				while(stream.hasNext()){
					m.put(stream.next(), stream.next());
					
				}
			}
			
			ExecutorService executor = Executors.newCachedThreadPool();
			
			int i = 1;
			while (true) {
			Socket incoming = s.accept();
			System.out.println("Spawning: " + i);
			//executor.execute(new ServeThread(incoming, m));
			Runnable r = new ServeThread(incoming, m);
			Thread t = new Thread(r);
			t.start();
			i++;
			}
			
			
			
		}catch(IOException ex){
			ex.printStackTrace();
		}
	}

}
