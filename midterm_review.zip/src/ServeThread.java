import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class ServeThread implements Runnable {

	public HashMap<String, String> m;
	public Socket incoming;
	public String commandstring = "Type ready to play, or bye to exit";
	public String winstring = "Thats the correct answer! Would you like to play again?";
	public String losestring = "Thats incorrect. Would you like to try again?";
	
	public ServeThread(Socket s, HashMap map){
		this.incoming = s;
		this.m = map;
	}
	
	public void game(ObjectInputStream in, ObjectOutputStream out){
		try{
		Boolean bool = true;
		int continueflag = 1;
		String recievedstring = null;
		
		out.writeUTF(commandstring);
		//yield for other threads
		Thread.yield();
		
		//check the given command
		while(bool == true){
		recievedstring = in.readUTF();
		if(recievedstring == "bye"){
			out.writeUTF("goodbye");
			bool = false;
			continueflag = 0;
		}else if(recievedstring == "ready"){
			bool = false;
		}else{
			out.writeUTF("I'm sorry that command is invalid");
		}
		}
		//if block start
		if(continueflag == 1){
			
			Random random = new Random();
			//create an arraylist using the Arraylist(set) constructor passing the set of m's keys
			List<String> keys = new ArrayList<String>(m.keySet());
			String randomKey = keys.get( random.nextInt(keys.size()));
			String value = m.get(randomKey);
			out.writeUTF("What state has " + randomKey + "as it�s state capital city?");
			recievedstring = in.readUTF();
			//check if the user has the right answer.
				if(recievedstring ==  value){
					out.writeUTF(winstring);
					out.writeUTF(commandstring);
				}else{
					out.writeUTF(losestring);
					out.writeUTF(commandstring);
				}
				
				recievedstring = in.readUTF();
				Boolean ifbool = true;
				while(ifbool == true){
					recievedstring = in.readUTF();
					if(recievedstring == "bye"){
						out.writeUTF("goodbye");
						ifbool = false;
						continueflag = 0;
					}else if(recievedstring == "ready"){
						ifbool = false;
					}else{
						out.writeUTF("I'm sorry that command is invalid");
					}
					}
				if(continueflag == 1){
					//yield before starting new game
					Thread.yield();
					//start new game
					game(in, out);
				}
		}
		
		}catch(IOException ioex) {
			ioex.printStackTrace();
			}
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try{
			Boolean bool = true;
			int continueflag = 1;
		ObjectInputStream in = new ObjectInputStream(this.incoming.getInputStream());
		ObjectOutputStream out = new ObjectOutputStream(this.incoming.getOutputStream());
		String recievedstring = null;
		
		
		out.writeUTF("Welcome to the Guess the Capital of State Game.");
		game(in, out);
		
	/**	out.writeUTF(commandstring);
		//yield for other threads
		Thread.yield();
		
		//check the given command
		while(bool == true){
		recievedstring = in.readUTF();
		if(recievedstring == "bye"){
			out.writeUTF("goodbye");
			bool = false;
			continueflag = 0;
		}else if(recievedstring == "ready"){
			bool = false;
		}else{
			out.writeUTF("I'm sorry that command is invalid");
		}
		}
		//if block start
		if(continueflag == 1){
			
			Random random = new Random();
			//create an arraylist using the Arraylist(set) constructor passing the set of m's keys
			List<String> keys = new ArrayList<String>(m.keySet());
			String randomKey = keys.get( random.nextInt(keys.size()));
			String value = m.get(randomKey);
			out.writeUTF("What state has " + randomKey + "as it�s state capital city?");
			recievedstring = in.readUTF();
			//check if the user has the right answer.
				if(recievedstring ==  value){
					
				}
			
		}
		//if block end
		**/
		}catch(IOException ioex) {
		ioex.printStackTrace();
		}
	}

}
