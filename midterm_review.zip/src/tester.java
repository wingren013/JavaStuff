import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;


public class tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			
		File file = new File("State-Capitals.txt");
		FileInputStream fin = new FileInputStream(file);
		//BufferedInputStream in = new BufferedInputStream(this.incoming.getInputStream());
		//BufferedOutputStream out = new BufferedOutputStream(this.incoming.getOutputStream());
		HashMap<String, String> map = new HashMap();
		try(Scanner stream = new Scanner(file).useDelimiter("[,]")){
			while(stream.hasNext()){
				/**String string1 = stream.next();
				String string2 = null;
				if(stream.hasNext()){
					string2 = stream.next();
				}
				System.out.println(string1);
				System.out.println(string2);
				map.put(string1, string2);**/
				map.put(stream.next(), stream.next());
				
			}
			Random random = new Random();
			List<String> keys = new ArrayList<String>(map.keySet());
			String randomKey = keys.get( random.nextInt(keys.size()) );
			String value = map.get(randomKey);
			System.out.println(value);
			
		}
		
		}catch(IOException ioex) {
		ioex.printStackTrace();
		}
	}

}
