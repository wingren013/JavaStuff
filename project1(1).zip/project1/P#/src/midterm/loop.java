package midterm;

public class loop {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum =0;
for(int i = 1; i<8; i++){
	sum = sum*10;
	sum += i;
	System.out.println(sum);
}
	}

}
