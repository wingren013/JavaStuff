package Practice;

public class Math_Practice {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(1+2+3+4+5+6+7+8+9);
System.out.println(4*(1.0-(1/3)+(1/5)-(1/7)+(1/9)-(1/11)));
System.out.println(4*(1.0-(1/3)+(1/5)-(1/7)+(1/9)-(1/11)+(1/13)));
System.out.println(2*5.5*3.1416);
System.out.println(5.5*5.5*3.1416);
	}

}
