package Practice;

import classwork.test;

public class Redd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		test john;
	}
	
	public int thiser(int x, int y){
		Redd i = this;
		System.out.println(i);
		return (Integer) null;
	}

}
