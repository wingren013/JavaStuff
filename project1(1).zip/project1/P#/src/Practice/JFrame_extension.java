package Practice;

import javax.swing.JFrame;

public class JFrame_extension extends JFrame {

	public static void main(String[] args) {
		

	}
	JFrame_extension(){
		
	}

}
