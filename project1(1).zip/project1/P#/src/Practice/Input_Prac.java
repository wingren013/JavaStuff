package Practice;
import java.util.Scanner;
public class Input_Prac {
	final double PI=3.1415;
	

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
@SuppressWarnings("resource")
Scanner input = new Scanner(System.in);
	int thing = input.nextInt();
	System.out.println(thing);
		System.out.println(67%10);
		
	}

}
