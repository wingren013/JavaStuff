package misc;

public class pracForopera {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x = 1;
		int y = 2;
		int z = 3;
		
		if (x==1 && y==2 || z==3){
			System.out.println("stuff");
		}
				
	}

}
