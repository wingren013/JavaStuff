package classwork;

public class bubble_sort {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
for (int red = 8; red >= 10; red++){
	for (int black = 0; black <= red; black--){
	}
}
	}

}