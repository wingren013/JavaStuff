package assignments;

public class math_random {

	public static void main(String[] args) {
		int x1= (int) (25+Math.random()*51);
		int y1= (int) (25+Math.random()*51);
		int z1= (int) (25+Math.random()*51);
		int a1= (int) (25+Math.random()*51);
		int b1= (int) (25+Math.random()*51);
		int c1= (int) (25+Math.random()*51);

		System.out.println(x1);
		System.out.println(y1);
		System.out.println(z1);
		System.out.println(a1);
		System.out.println(b1);
		System.out.println(c1);
		
		int x2= (int) (25+Math.random()*51);
		int y2= (int) (25+Math.random()*51);
		int z2= (int) (25+Math.random()*51);
		int a2= (int) (25+Math.random()*51);
		int b2= (int) (25+Math.random()*51);
		int c2= (int) (25+Math.random()*51);

		System.out.println(x2);
		System.out.println(y2);
		System.out.println(z2);
		System.out.println(a2);
		System.out.println(b2);
		System.out.println(c2);
		
		int x3= (int) (25+Math.random()*51);
		int y3= (int) (25+Math.random()*51);
		int z3= (int) (25+Math.random()*51);
		int a3= (int) (25+Math.random()*51);
		int b3= (int) (25+Math.random()*51);
		int c3= (int) (25+Math.random()*51);

		System.out.println(x3);
		System.out.println(y3);
		System.out.println(z3);
		System.out.println(a3);
		System.out.println(b3);
		System.out.println(c3);
		
		int x4= (int) (25+Math.random()*51);
		int y4= (int) (25+Math.random()*51);
		int z4= (int) (25+Math.random()*51);
		int a4= (int) (25+Math.random()*51);
		int b4= (int) (25+Math.random()*51);
		int c4= (int) (25+Math.random()*51);

		System.out.println(x4);
		System.out.println(y4);
		System.out.println(z4);
		System.out.println(a4);
		System.out.println(b4);
		System.out.println(c4);
		
		int x5= (int) (25+Math.random()*51);
		int y5= (int) (25+Math.random()*51);
		int z5= (int) (25+Math.random()*51);
		int a5= (int) (25+Math.random()*51);
		int b5= (int) (25+Math.random()*51);
		int c5= (int) (25+Math.random()*51);

		System.out.println(x5);
		System.out.println(y5);
		System.out.println(z5);
		System.out.println(a5);
		System.out.println(b5);
		System.out.println(c5);
		
		int x6= (int) (25+Math.random()*51);
		int y6= (int) (25+Math.random()*51);
		int z6= (int) (25+Math.random()*51);
		int a6= (int) (25+Math.random()*51);
		int b6= (int) (25+Math.random()*51);
		int c6= (int) (25+Math.random()*51);

		System.out.println(x6);
		System.out.println(y6);
		System.out.println(z6);
		System.out.println(a6);
		System.out.println(b6);
		System.out.println(c6);
	}

}
