package Individual_Work;

public class Average_Speed_in_Miles {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println((14/1.6)/(45.5/60));
System.out.println(8.7/(45.5/60));
System.out.println(8.75/(45.5/60));
	}

}
