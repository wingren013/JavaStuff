import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.io.*;
import java.net.*;
import java.text.DecimalFormat;
import java.util.Scanner;

public class client {

	
	public client(){

	}
	
	public static void start(double x, double y, double z){
	
	try {
		
		// Create a socket to connect to the server
		Socket socket = new Socket("localhost", 8000);
		
		// Create an input stream to receive data from the server
		DataInputStream streamReader = new DataInputStream(socket.getInputStream());
		
		// Create an output stream to send data to the server
		DataOutputStream streamWriter = new DataOutputStream(socket.getOutputStream());
		
		
		streamWriter.writeDouble(x);
		streamWriter.writeDouble(y);
		streamWriter.writeDouble(z);
		
		double ret1 = streamReader.read();
		double ret2 = streamReader.read();

		streamReader.close();
		streamWriter.close();

		DecimalFormat format = new DecimalFormat("####.###");
		
		
		
		
		//System.out.println(streamReader.read());
		System.out.println(format.format(ret1));
		System.out.println(format.format(ret2));
	
	
	}
	
	
		catch (IOException ex) {
		}
	}
	
	public static void main(String[] args){
		
		double x = 0;
		double y = 0;
		double z = 0;
		try(Scanner in = new Scanner(System.in)){
			x = Double.parseDouble(in.next());
			y = Double.parseDouble(in.next());
			z = Double.parseDouble(in.next());
		}
		
		start(x, y, z);
	}
	
}

	
	
