import java.text.DecimalFormat;


public class Loan {
	private double payment = 0;
	private double presentValue = 0;
	private double ratePerPeriod = 0;
	private double numberOfPeriods = 0;
	
	public Loan(){
	}
	
	public Loan(double x, double y, double z){
		this.presentValue = x;
		this.ratePerPeriod = (y/12)/100;
		this.numberOfPeriods = z*12;
	}
	
	public synchronized double getpayment(){
		return this.payment;
	}
	
	public synchronized void setpayment(double x){
		this.payment = x;
	}
	
	public double getpresentValue(){
		return this.presentValue;
	}
	
	public void setpresentValue(double x){
		this.presentValue = x;
	}
	
	public double getratePerPeriod(){
		return this.ratePerPeriod;
	}
	
	public void setratePerPeriod(double x){
		this.ratePerPeriod = x;
	}
	
	public double getnumberOfPeriods(){
		return this.numberOfPeriods;
	}
	
	public void setnumberOfPeriods(double x){
		this.numberOfPeriods = x;
	}
	
	
	
	public double calculatePayment(){
		double numerator = this.ratePerPeriod * this.presentValue;
		double denominator = 1 - Math.pow(this.ratePerPeriod + 1, this.numberOfPeriods * -1);
		double x  = numerator / denominator;
		this.setpayment(x);
		//System.out.println(numerator);
		//System.out.println(denominator);
		//System.out.println(x);
		return x;
	}
	
	public double calculatetotal(){
		double total = this.payment*this.numberOfPeriods;
		return total;
	}
	
	
	
	
	
}
