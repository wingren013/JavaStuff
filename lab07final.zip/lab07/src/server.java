import java.io.*;
import java.util.*;
import java.net.*;

public class server {
	
	public server(){
		
	}
	public static void main(String[] args) {
		// Establish server socket
		try (ServerSocket s = new ServerSocket(8000)) {
			
			// Wait for client connection
			try (Socket incoming = s.accept()) {
				
				DataInputStream inStream = new DataInputStream(incoming.getInputStream());
				DataOutputStream outStream = new DataOutputStream(incoming.getOutputStream());
				
				double x = inStream.readDouble();
				double y = inStream.readDouble();
				double z = inStream.readDouble();
				
				Loan loan = new Loan(x, y, z);
				
				//Loan loan = new Loan(inStream.readDouble(), inStream.readDouble(), inStream.readDouble());
				//outStream.writeDouble(7);
				double res1 = loan.calculatePayment();
				double res2 = loan.calculatetotal();
				
				outStream.writeDouble(res1);
				outStream.writeDouble(res2);
				inStream.close();
				outStream.close();
				
				
				
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}
