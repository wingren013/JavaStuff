import java.util.List;


public class display {

	/**
	 * @param args
	 */
	public static void displayer(List list){
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
