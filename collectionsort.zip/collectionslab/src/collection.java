import java.awt.List;
import java.util.ArrayList;;


public class collection {
ArrayList list;

collection(){
	this.list = new ArrayList();
	List orderedlist = new List();
}


}
