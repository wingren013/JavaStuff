import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class sort {

	/**
	 * @param args
	 */
	public static List sorter(List list){
		Collections.sort(list);
		return list;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
