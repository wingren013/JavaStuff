import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Binary_To_File {


	public static void inputINT(int x) throws IOException {
		File file = new File("lab02_01.dat");
		try (FileOutputStream stream = new FileOutputStream(file, true)){
			stream.write(x);
		}
		
	}
	
	public static void display(File file) throws FileNotFoundException, IOException{
		try(FileInputStream stream = new FileInputStream(file)){
			int l = stream.available();
			
		for(int i = 1; i <= l; i++){
			System.out.println(stream.read());
		}
		}
		
	}
	
	
}
