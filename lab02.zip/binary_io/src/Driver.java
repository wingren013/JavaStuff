import java.io.File;
import java.io.IOException;


public class Driver {

	
	
	
	
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file = new File("lab02_01.dat");
		for(int i = 1; i <= 10; i++){
			Binary_To_File.inputINT(Dice.d50());
		}
		Binary_To_File.display(file);
		
	}


}
