import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TrackerWriter {

	public static void createTracker() throws IOException{
		int x = 1;
		File file = new File("lab02_02.dat");
		if(file.exists()){
		try(Scanner input = new Scanner(file)){
			if(input.hasNextLine()){
					String yString = input.next();
					int y = Integer.parseInt(yString);
			x = x + y;
			}
		}
		try(PrintWriter output = new PrintWriter(file)){
			output.print(x);
		}
		}else{
			try(PrintWriter output = new PrintWriter(file)){
				output.print(x);
			}
		}

		
	}
}
