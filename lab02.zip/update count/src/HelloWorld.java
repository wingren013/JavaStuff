
public class HelloWorld {
	
	public static void helloworld(){
		System.out.println("hello_world");
	}

}
